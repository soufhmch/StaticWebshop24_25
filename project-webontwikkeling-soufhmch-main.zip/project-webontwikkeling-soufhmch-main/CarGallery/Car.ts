import { SignificantModel } from "./SignificantModel";
export interface Car {
  id: number;
  name: string;
  description: string;
  founded: string;
  discontinued: boolean;
  headquarters: string;
  image_url: string;
  popular_models: string[];
  significant_model: SignificantModel;
}
