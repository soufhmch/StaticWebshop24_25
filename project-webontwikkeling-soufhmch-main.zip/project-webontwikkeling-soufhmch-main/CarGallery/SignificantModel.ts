export interface SignificantModel {
  id: number;
  name: string;
  release_year: number;
  type: string;
  iconic?: string;
  production?: number;
  Engine: string;
}
