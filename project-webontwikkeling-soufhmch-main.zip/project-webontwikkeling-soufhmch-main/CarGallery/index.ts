import * as readline from "readline-sync";
import { Car } from "./Car";

const cars = fetch(
  "https://raw.githubusercontent.com/soufhmch/WebOntwikkeling/main/project/milestone1.json"
)
  .then((res) => res.json())
  .then((data) => menu(data as Car[]));

function ShowAllCars(data: Car[]) {
  console.log("Here is a list of all the cars in the JSON file: ");
  for (let i = 0; i < data.length; i++) {
    console.log(data[i].name + ": " + data[i].founded);
  }
}
function FilterCarsById(data: Car[]) {
  console.log("Enter the id of the car you want to filter by: ");
  let id = readline.questionInt();
  console.log(
    "Here is a list of all the cars in the JSON file that match the id you entered: "
  );
  for (let i = 0; i < data.length; i++) {
    if (data[i].id == id) {
      console.log(data[i].name + ": " + data[i].founded);
    }
  }
}
function menu(data: Car[]) {
  let menuOptions: string[] = [
    "1. Show all Cars",
    "2. Filter Cars by id",
    "3. Exit",
  ];

  let subMenuOption = readline.keyInSelect(
    menuOptions,
    "Welcome to the ultimate Car JSON data viewer. Choose an option: ",
    { cancel: false, guide: false }
  );

  while (subMenuOption !== 2) {
    switch (subMenuOption) {
      case 0:
        ShowAllCars(data);
        break;
      case 1:
        FilterCarsById(data);
        break;
      default:
        console.log("Please choose a valid option.");
        break;
    }

    subMenuOption = readline.keyInSelect(
      menuOptions,
      "Welcome to the ultimate Car JSON data viewer. Choose an option: ",
      { cancel: false, guide: false }
    );
  }
}
const fetchFromUrl = async () => {
  const response = await fetch(
    "https://raw.githubusercontent.com/soufhmch/WebOntwikkeling/main/project/milestone1.json"
  );
  const data = await response.json();
  menu(data);
};

fetchFromUrl();

export {};
