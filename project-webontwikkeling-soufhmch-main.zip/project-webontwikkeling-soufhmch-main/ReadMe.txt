To set up and run this project, navigate to the `Milestone2` folder and open the integrated terminal. 
Install the necessary dependencies by typing `npm i`.
After the dependencies are installed, go to the `views` folder using `cd views` and start the application by running `npm start`. 
Your application should now be running and accessible.
