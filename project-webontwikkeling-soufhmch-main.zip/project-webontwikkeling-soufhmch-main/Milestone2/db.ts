import { MongoClient, Db, ObjectId } from "mongodb";
import dotenv from "dotenv";
import fetch from "node-fetch";
import bcrypt from "bcryptjs";

dotenv.config();

const url: string = process.env.MONGODB_URI as string;
const dbName: string = "carsDB";
const client: MongoClient = new MongoClient(url);

let db: Db;

async function connectDb(): Promise<Db> {
  if (db) return db;
  try {
    await client.connect();
    console.log("Connected successfully to MongoDB Atlas");
    db = client.db(dbName);
    return db;
  } catch (error) {
    console.error("Failed to connect to MongoDB Atlas", error);
    throw new Error("Failed to connect to MongoDB Atlas");
  }
}

async function fetchAndStoreData(apiUrl: string, collectionName: string) {
  const db = await connectDb();
  const collection = db.collection(collectionName);
  const response = await fetch(apiUrl);
  const data: any[] = await response.json();

  const transformedData = data.map((item) => {
    if (item.related_models) {
      item.related_models = item.related_models.map(
        (id: string) => new ObjectId(id)
      );
    }
    return item;
  });

  await collection.insertMany(transformedData);
  console.log(`Data from ${apiUrl} inserted into ${collectionName} collection`);
}

async function initializeDb() {
  const db = await connectDb();
  const carCount = await db.collection("cars").countDocuments();
  const modelsCount = await db.collection("models").countDocuments();
  const userCount = await db.collection("users").countDocuments();

  if (carCount === 0) {
    await fetchAndStoreData(
      "https://raw.githubusercontent.com/soufhmch/WebOntwikkeling/main/project/milestone1.json",
      "cars"
    );
  }
  if (modelsCount === 0) {
    await fetchAndStoreData(
      "https://raw.githubusercontent.com/soufhmch/WebOntwikkeling/main/project/significantModels.json",
      "models"
    );
  }
  if (userCount === 0) {
    const salt = await bcrypt.genSalt(10);
    const adminPassword = await bcrypt.hash(
      process.env.ADMIN_PASSWORD as string,
      salt
    );
    const userPassword = await bcrypt.hash("userpassword", salt);

    await db.collection("users").insertMany([
      {
        username: process.env.ADMIN_EMAIL,
        password: adminPassword,
        role: "ADMIN",
      },
      { username: "user@example.com", password: userPassword, role: "USER" },
    ]);
    console.log("Default users added");
  }
}

export { connectDb, initializeDb, fetchAndStoreData };
