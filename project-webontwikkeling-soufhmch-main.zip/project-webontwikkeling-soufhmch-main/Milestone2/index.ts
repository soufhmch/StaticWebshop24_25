import express, { Request, Response, NextFunction } from "express";
import { connectDb, initializeDb } from "./db";
import { ObjectId } from "mongodb";
import path from "path";
import dotenv from "dotenv";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import bcrypt from "bcryptjs";
import MongoStore from "connect-mongo";

// Load environment variables from .env file
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set the view engine to EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, "public")));

// Session configuration
app.use(
  session({
    secret: "your_secret_key",
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
    cookie: { maxAge: 1000 * 60 * 60 * 24 }, // 1 day
  })
);

// Define User interface
interface User {
  _id: ObjectId;
  username: string;
  password: string;
  role: string;
}

// Passport configuration
passport.use(
  new LocalStrategy(
    async (username: string, password: string, done: Function) => {
      const db = await connectDb();
      const user = await db.collection<User>("users").findOne({ username });

      if (!user) {
        return done(null, false, { message: "Incorrect username." });
      }

      const isMatch = await bcrypt.compare(password, user.password);

      if (!isMatch) {
        return done(null, false, { message: "Incorrect password." });
      }

      return done(null, user);
    }
  )
);

passport.serializeUser((user: Express.User, done) => {
  done(null, (user as User)._id);
});

passport.deserializeUser(async (id: string, done) => {
  const db = await connectDb();
  const user = await db
    .collection<User>("users")
    .findOne({ _id: new ObjectId(id) });
  done(null, user);
});

app.use(passport.initialize());
app.use(passport.session());

// Initialize the database
initializeDb().catch((error) => {
  console.error("Failed to initialize the database", error);
});

// Middleware to check if user is authenticated
function ensureAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect("/login");
}

// Middleware to check if user is admin
function ensureAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && (req.user as User)?.role === "ADMIN") {
    return next();
  }
  res.redirect("/");
}

// Route to render the home page
app.get("/", (req: Request, res: Response) => {
  res.render("index", { title: "Home", user: req.user });
});

// Route to render the car gallery with filtering and sorting
app.get("/cars", async (req: Request, res: Response) => {
  const { filter, sortField, sortOrder } = req.query;
  try {
    const db = await connectDb();
    console.log("Connected to database");

    let query = {};
    if (filter) {
      query = { name: { $regex: filter as string, $options: "i" } };
    }
    console.log("Query:", query);

    let sort = {};
    if (sortField && sortOrder) {
      sort = { [sortField as string]: sortOrder === "asc" ? 1 : -1 };
    }
    console.log("Sort:", sort);

    const cars = await db.collection("cars").find(query).sort(sort).toArray();
    console.log("Cars retrieved:", cars);

    res.render("cars", { cars, filter, sortField, sortOrder, user: req.user });
  } catch (error) {
    console.error("Failed to retrieve cars from MongoDB", error);
    res.status(500).send("Failed to retrieve cars");
  }
});

// Route to render the car detail page
app.get("/car/:id", async (req: Request, res: Response) => {
  const carId = req.params.id;
  try {
    const db = await connectDb();
    console.log("Connected to database");

    const car = await db
      .collection("cars")
      .findOne({ _id: new ObjectId(carId) });
    if (!car) {
      return res.status(404).send("Car not found");
    }
    console.log("Car retrieved:", car);

    // Fetch related models
    let relatedModels: any[] = [];
    if (car.related_models && car.related_models.length > 0) {
      const relatedModelIds = car.related_models.map(
        (id: string) => new ObjectId(id)
      );
      relatedModels = await db
        .collection("cars")
        .find({ _id: { $in: relatedModelIds } })
        .toArray();
    }
    console.log("Related models retrieved:", relatedModels);

    res.render("carsdetail", { car, relatedModels, user: req.user });
  } catch (error) {
    console.error("Failed to retrieve car from MongoDB", error);
    res.status(500).send("Failed to retrieve car");
  }
});

app.get("/login", (req: Request, res: Response) => {
  if (req.isAuthenticated()) {
    return res.redirect("/");
  }
  res.render("login", { user: req.user });
});

app.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/",
    failureRedirect: "/login",
    failureFlash: true,
  })
);

app.get("/register", (req: Request, res: Response) => {
  res.render("register", { user: req.user });
});

app.post("/register", async (req: Request, res: Response) => {
  const { username, password } = req.body;
  const db = await connectDb();
  const existingUser = await db.collection<User>("users").findOne({ username });

  if (existingUser) {
    return res.render("register", {
      error: "Username already exists",
      user: req.user,
    });
  }

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const newUser: User = {
    _id: new ObjectId(),
    username,
    password: hashedPassword,
    role: "USER",
  };

  await db.collection<User>("users").insertOne(newUser);

  res.redirect("/login");
});

app.post("/logout", (req: Request, res: Response) => {
  req.logout((err: any) => {
    if (err) {
      console.error("Failed to log out", err);
      return res.status(500).send("Failed to log out");
    }
    res.redirect("/login");
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
