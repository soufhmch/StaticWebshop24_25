function sortFunction() {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
    table = document.getElementById("objectsTable");
    switching = true;
    // Set the sorting direction to ascending:
    dir = "asc";

    while (switching) {
        switching = false;
        rows = table.rows;

        for (i = 1; i < (rows.length - 1); i++) {
            shouldSwitch = false;
            x = rows[i].getElementsByTagName("TD")[0]; // Assumes we are sorting by the first column
            y = rows[i + 1].getElementsByTagName("TD")[0];

            // Check if the two rows should switch place, based on the direction, asc or desc:
            if (dir == "asc") {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchcount++;
        } else {
            // If no switching has been done AND the direction is "asc",
            // set the direction to "desc" and run the while loop again.
            if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}

// To initially call the sort function when the user changes the sorting criteria, you could implement something like:
document.getElementById("sortSelect").addEventListener("change", function () {
    var optionSelected = this.value.split("-");
    var sortField = optionSelected[0]; // the field to sort by
    var sortOrder = optionSelected[1]; // 'asc' or 'desc'
    sortTableByColumn(sortField, sortOrder);
});

function sortTableByColumn(column, order) {
    // Modify the sortFunction to take column and order into consideration
}